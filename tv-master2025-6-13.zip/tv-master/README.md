# tv

 介绍
此项目是博主自己整理的江苏yidong的电视yuan，仅限于江苏yidong网络，其他省份或者网络自测。


 使用说明

1.  m3u或者txt格式复制到电视播放器或者IOS的APTV就行
2.  推荐电视用酷9或者ok影视，IOS用APTV


如有问题可发e-mail联系博主：chhb3675@163.com




